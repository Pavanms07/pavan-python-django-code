from django.apps import AppConfig


class Dream2Config(AppConfig):
    name = 'Dream2'
