from django.contrib import admin
#from django.contrib.auth.admin import UserAdmin
from Dream2.models import Post
from Dream2.models import Profile
# Register your models here.



admin.site.register(Post)
admin.site.register(Profile)
#admin.site.register(UserAdmin)

