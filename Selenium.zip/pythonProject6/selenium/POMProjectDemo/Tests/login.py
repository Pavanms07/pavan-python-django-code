from selenium import webdriver
import time
driver = webdriver.Chrome(executable_path="C:\\Users\\Admin\\Downloads\\chromedriver_win32\\chromedriver.exe")

driver.implicitly_wait(20)
driver.maximize_window()


driver.get("https://www.saucedemo.com/")

driver.find_element_by_id("user-name").send_keys("standard_user")
driver.find_element_by_id("password").send_keys("secret_sauce")
driver.find_element_by_id("login-button").click()
driver.find_element_by_id("shopping_cart_container").click()


driver.find_element_by_link_text("CHECKOUT").click()
driver.find_element_by_id("first-name").send_keys("PAVAN")
driver.find_element_by_id("last-name").send_keys("M S")
driver.find_element_by_id("postal-code").send_keys("573201")

#Submit or Continue is not correct for testing

# driver.find_element_by_id("logout_sidebar_link").click()

# driver.find_element_by_link_text("Open Menu")

time.sleep(3)

driver.close()

driver.quit()
print("Test Completed")